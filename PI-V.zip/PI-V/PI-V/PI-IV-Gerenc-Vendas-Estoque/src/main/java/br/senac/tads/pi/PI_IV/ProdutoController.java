package br.senac.tads.pi.PI_IV;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.*;

@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService produtoService;

    @GetMapping
    public List<Produto> listarProdutos() {
        return produtoService.listarProdutos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Produto> getProduto(@PathVariable Long id) {
        Optional<Produto> produtoOpt = produtoService.buscarProdutoPorId(id);
        
        if (produtoOpt.isPresent()) {
            return ResponseEntity.ok(produtoOpt.get());
        } else {
            throw new ProdutoNotFoundException(id);
        }
    }

    @PostMapping
    public ResponseEntity<?> incluir(@Valid @RequestBody Produto produto) {
        produtoService.salvarProduto(produto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<Produto> editarProduto(@PathVariable Long id, @RequestBody Produto produto) {
        Optional<Produto> produtoOpt = produtoService.buscarProdutoPorId(id);
        
        if (!produtoOpt.isPresent()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        
        Produto produtoExistente = produtoOpt.get();
        produtoExistente.setCodigo(produto.getCodigo());
        produtoExistente.setNome(produto.getNome());
        produtoExistente.setDescricao(produto.getDescricao());
        produtoExistente.setMarca(produto.getMarca());
        produtoExistente.setQuantidade(produto.getQuantidade());
        produtoExistente.setPreco(produto.getPreco());
    
        Produto produtoAtualizado = produtoService.salvarProduto(produtoExistente);
        return ResponseEntity.ok(produtoAtualizado);
    }
    

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluirProduto(@PathVariable Long id) {
        produtoService.excluirProduto(id);
        return ResponseEntity.noContent().build(); 
    }
}

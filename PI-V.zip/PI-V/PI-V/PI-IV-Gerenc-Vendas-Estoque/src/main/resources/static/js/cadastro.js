var id = null;
document.getElementById('cadastroForm').addEventListener('submit', function enviarDados(evt) {
    evt.preventDefault();
    if (id === null) {
        salvarDadosUsuario();
    } else {
        editarDadosUsuario();
    }
});

async function salvarDadosUsuario() {
    const form = document.getElementById('cadastroForm');

    let dados;

    dados = {
        email: form.login.value,
        nome: form.nome.value,
        senha: form.senha.value,
        telefone: form.telefone.value,
        endereco: form.endereco.value,
        numero: form.numero.value,
        cep: form.cep.value,
        identificador: form.cpfCnpj.value,
        tipo: form.tipoUser.value,
    }
    console.log("DADOS " + JSON.stringify(dados))

    if (dados.tipo == 0 || dados.tipo == 1) {
        console.log("Dentro do if")
        const httpResp = await fetch('/api/motoparts/cliente', {
            method: 'post',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            console.log("ERROS " + erros.mensagem);
            alert(erros.mensagem);

            if (erros.erros !== null) {
                for (const erro of erros.errors) {
                    const mensagem = erro.defaultMessage;
                    const field = erro.field;
                    console.log(mensagem)
                }
            }
            return;
        }
        alert('Sucesso ao salvar cliente');
    } 
}

async function editarDadosUsuario() {
    console.log("Editar" + id)
    const form = document.getElementById('cadastroForm');

    let tipo = form.tipoUser.value;

    let dados = {
        email: form.login.value,
        senha: form.senha.value,
        nome: form.nome.value,
        telefone: form.telefone.value,
        endereco: form.endereco.value,
        numero: form.numero.value,
        cep: form.cep.value,
        identificador: form.cpfCnpj.value,
        tipo: form.tipoUser.value,
    }

    if (tipo == 0 || tipo == 1) {
        const httpResp = await fetch(`/api/motoparts/usuario/${id}`, {
            method: 'PUT',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            for (const erro of erros.errors) {
                const mensagem = erro.defaultMessage;
                const field = erro.field;
                console.log(mensagem)
            }
        }

        alert('Sucesso ao editar cliente ');
        document.getElementById('cadastroForm').reset();


    } else {
        const httpResp = await fetch(`/api/motoparts/usuario/${id}`, {
            method: 'PUT',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            for (const erro of erros.errors) {
                const mensagem = erro.defaultMessage;
                const field = erro.field;
                console.log(mensagem)
            }
        }
        alert('Sucesso ao editar fornecedor');
        document.getElementById('cadastroForm').reset();

    }
}

async function carregarUsuarios() {

        const resposta = await fetch('/api/motoparts/usuario');
        console.log("Resposta " + resposta);

        if (!resposta.ok) {
            throw new Error('Erro ao carregar os dados da API.');
            return;
        }
        const dados = await resposta.json();

        console.log(dados);

    const tabelaCorpo = document.getElementById('estoqueUsuario');

    tabelaCorpo.innerHTML = '';

    if (dados && dados.length > 0) {
        // Iterar sobre cada item e criar a linha da tabela
        dados.forEach(item => {
            // Criar uma nova linha (<tr>)
            const linha = document.createElement('tr');

            let tipo = "";
            if (item.permissoes[0].id == 1) {
                tipo = "Admin";
            } else {
                tipo = "Funcionario";
            }

            const colunas = [
                item.id,
                tipo,
                item.nome,
                item.identificador,
                item.email,
                item.endereco,
                item.numero,
                item.cep,
                item.telefone,

            ];

            // Para cada coluna, criar uma célula e adicionar à linha
            colunas.forEach(dado => {
                const celula = document.createElement('td');
                celula.textContent = dado;
                linha.appendChild(celula);
            });

            //Célula para o ícone de editar (ex: lápis)
            const editarCelula = document.createElement('td');
            editarCelula.innerHTML = '<a href="#" style="color: #343a40"> <i class="fas fa-pencil-alt"></i></a>'; // Ícone de lápis
            editarCelula.addEventListener('click', () => editarItem(item.id)); // Adicionar ação de editar
            linha.appendChild(editarCelula);

            const visualizarCelula = document.createElement('td');
            visualizarCelula.innerHTML = '<a href="#" style="color: #343a40"> <i class="fas fa-id-card"></i></a>'; // Ícone de id
            visualizarCelula.addEventListener('click', () => visualizarItem(item.id)); // Ação para visualizar
            linha.appendChild(visualizarCelula);

            const excluirCelula = document.createElement('td');
            excluirCelula.innerHTML = '<a href="#" style="color: #343a40"><i class="fas fa-trash-alt"></i></a>'; // Ícone de lixeira
            excluirCelula.addEventListener('click', () => excluirItem(item.id)); // Ação para excluir
            linha.appendChild(excluirCelula);

            // Adicionar a linha à tabela
            tabelaCorpo.appendChild(linha);
        });
    } else {
        // Se não houver dados,
        tabelaCorpo.innerHTML = '<tr><td colspan="10">Nenhum item encontrado.</td></tr>';
    }
}

var id = null;
document.getElementById('cadastroForm').addEventListener('submit', function enviarDados(evt) {
    evt.preventDefault();
    if (id === null) {
        salvarDadosUsuario();
    } else {
        editarDadosUsuario();
    }
});

async function salvarDadosUsuario() {
    const form = document.getElementById('cadastroForm');

    let dados;

    dados = {
        email: form.login.value,
        nome: form.nome.value,
        senha: form.senha.value,
        telefone: form.telefone.value,
        endereco: form.endereco.value,
        numero: form.numero.value,
        cep: form.cep.value,
        identificador: form.cpf.value,
        tipo: form.tipoUser.value,
    }
    console.log("DADOS " + JSON.stringify(dados))

    if (dados.tipo == 0 || dados.tipo == 1) {
        console.log("Dentro do if")
        const httpResp = await fetch('/api/motoparts/cliente', {
            method: 'post',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            console.log("ERROS " + erros.mensagem);
            alert(erros.mensagem);

            if (erros.erros !== null) {
                for (const erro of erros.errors) {
                    const mensagem = erro.defaultMessage;
                    const field = erro.field;
                    console.log(mensagem)
                }
            }
            return;
        }
        alert('Sucesso ao salvar cliente');
    } 
}

async function editarDadosUsuario() {
    console.log("Editar" + id)
    const form = document.getElementById('cadastroForm');

    let tipo = form.tipoUser.value;

    let dados = {
        email: form.login.value,
        senha: form.senha.value,
        nome: form.nome.value,
        telefone: form.telefone.value,
        endereco: form.endereco.value,
        numero: form.numero.value,
        cep: form.cep.value,
        identificador: form.cpf.value,
        tipo: form.tipoUser.value,
    }

    if (tipo == 0 || tipo == 1) {
        const httpResp = await fetch(`/api/motoparts/usuario/${id}`, {
            method: 'PUT',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            for (const erro of erros.errors) {
                const mensagem = erro.defaultMessage;
                const field = erro.field;
                console.log(mensagem)
            }
        }

        alert('Sucesso ao editar cliente ');
        document.getElementById('cadastroForm').reset();


    } else {
        const httpResp = await fetch(`/api/motoparts/usuario/${id}`, {
            method: 'PUT',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        if (!httpResp.ok) {
            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }
            const erros = await httpResp.json();
            for (const erro of erros.errors) {
                const mensagem = erro.defaultMessage;
                const field = erro.field;
                console.log(mensagem)
            }
        }
        alert('Sucesso ao editar fornecedor');
        document.getElementById('cadastroForm').reset();

    }
}

async function carregarUsuarios() {

    const resposta = await fetch('/api/motoparts/usuario');
    console.log("Resposta " + resposta);

    if (!resposta.ok) {
        throw new Error('Erro ao carregar os dados da API.');
        return;
    }
    const dados = await resposta.json();

    console.log(dados);

    const tabelaCorpo = document.getElementById('estoqueUsuario');

    tabelaCorpo.innerHTML = '';

    if (dados && dados.length > 0) {
        dados.forEach(item => {
            const linha = document.createElement('tr');

            let tipo = "";
            if (item.permissoes[0].id == 1) {
                tipo = "Admin";
            } else {
                tipo = "Funcionario";
            }

            const colunas = [
                item.id,
                tipo,
                item.nome,
                item.identificador,
                item.email,
                item.endereco,
                item.numero,
                item.cep,
                item.telefone,
            ];

            colunas.forEach(dado => {
                const celula = document.createElement('td');
                celula.textContent = dado;
                linha.appendChild(celula);
            });

            const editarCelula = document.createElement('td');
            editarCelula.innerHTML = '<a href="#" style="color: #343a40"> <i class="fas fa-pencil-alt"></i></a>';
            editarCelula.addEventListener('click', () => editarItem(item.id));
            linha.appendChild(editarCelula);

            const visualizarCelula = document.createElement('td');
            visualizarCelula.innerHTML = '<a href="#" style="color: #343a40"> <i class="fas fa-id-card"></i></a>';
            visualizarCelula.addEventListener('click', () => visualizarItem(item.id));
            linha.appendChild(visualizarCelula);

            const excluirCelula = document.createElement('td');
            excluirCelula.innerHTML = '<a href="#" style="color: #343a40"><i class="fas fa-trash-alt"></i></a>';
            excluirCelula.addEventListener('click', () => excluirItem(item.id));
            linha.appendChild(excluirCelula);

            tabelaCorpo.appendChild(linha);
        });
    } else {
        tabelaCorpo.innerHTML = '<tr><td colspan="10">Nenhum item encontrado.</td></tr>';
    }
}

function preencherModalComDados(dados) {

    document.getElementById('tipoUser').value = dados.tipo;
    document.getElementById('tipoPessoa').readOnly = true;
    document.getElementById('tipoUser').readOnly = true
    document.getElementById('tipoPessoa').readOnly = true;

    document.getElementById('senha').value = dados.senha || '';
    document.getElementById('endereco').value = dados.endereco || '';
    document.getElementById('numero').value = dados.numero || '';
    document.getElementById('cep').value = dados.cep || '';
    document.getElementById('telefone').value = dados.telefone || '';

    // Campos bloqueados para edição
    document.getElementById('nome').value = dados.nome || ''; // bloqueado
    document.getElementById('cpf').value = dados.identificador || ''; // bloqueado
    document.getElementById('login').value = dados.email || '';  // bloqueado

    document.getElementById('nome').readOnly = true;
    document.getElementById('cpf').readOnly = true;
    document.getElementById('login').readOnly = true;
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('collapsed');
}

function toggleSubMenu(subMenuId) {
    const allSubMenus = document.querySelectorAll('.sub-menu');
    allSubMenus.forEach(subMenu => {
        subMenu.classList.remove('active');
    });
    const currentSubMenu = document.getElementById(subMenuId);
    currentSubMenu.classList.toggle('active');
}

function handleTipoPessoaChange() {
    const tipoPessoa = document.getElementById('tipoPessoa').value;
    const cpf = document.getElementById('cpf');
    cpf.value = "";

    if (tipoPessoa === "0") {
        cpf.placeholder = "Digite o CPF";
        cpf.setAttribute("maxlength", "14");
        cpf.oninput = formatarCPF;
    } else if (tipoPessoa === "1") {
        cpf.placeholder = "Digite o CNPJ";
        cpf.setAttribute("maxlength", "18");
        cpf.oninput = formatarCPF;
    }
}

// Função para validar CPF
function validateCPF(cpf) {
    cpf = cpf.replace(/[^\d]+/g, ''); // Remover qualquer caractere não numérico

    if (cpf.length !== 11) {
        return false;
    }

    // Lógica de validação do CPF (fórmula padrão)
    let sum = 0;
    let remainder;

    for (let i = 1; i <= 9; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }

    remainder = sum % 11;
    if (remainder === 10 || remainder === 11) {
        remainder = 0;
    }

    if (remainder !== parseInt(cpf.substring(9, 10))) {
        return false;
    }

    sum = 0;
    for (let i = 1; i <= 10; i++) {
        sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }

    remainder = sum % 11;
    if (remainder === 10 || remainder === 11) {
        remainder = 0;
    }

    if (remainder !== parseInt(cpf.substring(10, 11))) {
        return false;
    }

    return true;
}

// Função para formatar CPF
function formatarCPF(event) {
    let input = event.target;
    let value = input.value.replace(/\D/g, ''); // Remove tudo que não for número

    if (value.length <= 11) {
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d)/, '$1.$2');
        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }

    input.value = value;
}

// Função para formatar CEP
function formatarCEP(event) {
    let input = event.target;
    let value = input.value.replace(/\D/g, ''); // Remove tudo que não for número

    if (value.length <= 8) {
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
    }

    input.value = value;
}

// Função para formatar Telefone
function formatarTelefone(event) {
    let input = event.target;
    let value = input.value.replace(/\D/g, ''); // Remove tudo que não for número

    if (value.length <= 11) {
        value = value.replace(/^(\d{2})(\d)/, '($1) $2');
        value = value.replace(/(\d{5})(\d)/, '$1-$2');
    }

    input.value = value;
}

// Chama a função de manipulação ao mudar o Tipo de Usuário
document.getElementById('tipoUser').addEventListener('change', handleTipoUserChange);
document.getElementById('tipoPessoa').addEventListener('change', handleTipoPessoaChange);

// Inicializar a página com a função chamada
window.onload = function () {
    carregarUsuarios();
    handleTipoUserChange();
    document.getElementById('cadastroForm').reset();
};
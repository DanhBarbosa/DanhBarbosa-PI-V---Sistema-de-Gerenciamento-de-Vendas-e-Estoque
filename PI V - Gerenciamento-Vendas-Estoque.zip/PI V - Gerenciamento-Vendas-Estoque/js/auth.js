function logout(){
    window.location.href = '/logout';
    localStorage.clear();
}

function carregarTelas(){
    const dadosLocalStorage = JSON.parse(localStorage.getItem("dados"));
    const permissao = dadosLocalStorage.permissao;

    const cadastroUsuarios = document.getElementById("menuCadastros");

    if (permissao == 'FUNCIONARIO' ) {
        cadastroUsuarios.style.display = 'none';
    }  

}
carregarTelas();
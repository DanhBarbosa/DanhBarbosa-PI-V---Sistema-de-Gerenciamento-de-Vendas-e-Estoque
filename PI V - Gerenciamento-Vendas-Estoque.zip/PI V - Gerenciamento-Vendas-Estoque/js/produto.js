var idProduto = null;

document.getElementById('addItemEstoqueLojaForm').addEventListener('submit', function enviarDadosProduto(evt) {
    evt.preventDefault();
    if (idProduto === null) {
        salvarDadosProduto();
    } else {
        editarDadosProduto();
    }
});

// Operações CRUD

// SALVAR produto - OK
async function salvarDadosProduto() {
    const form = document.getElementById('addItemEstoqueLojaForm');

    const dadosProduto = {
        nome: form.txtNomeLoja.value,
        codProduto: form.txtCodItemLoja.value,
        marca: form.txtMarcaLoja.value,
        descricao: form.txtDescricaoLoja.value,
        quantidade: form.txtQtdeLoja.value,
        preco: form.txtPrecoLoja.value
    };

    const dadosLocalStorage = JSON.parse(localStorage.getItem("dados"));
    const idLocalStorage = dadosLocalStorage.id;

    try {
        const httpResp = await fetch(`/api/motoparts/produto/${idLocalStorage}`, {
            method: 'post',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(dadosProduto)
        });

        if (!httpResp.ok) {

            if (httpResp.status !== 400) {
                alert('Erro no envio dos dados - ' + httpResp.status);
                return;
            }

            const erros = await httpResp.json();
            for (const erro of erros.errors) {
                const mensagem = erro.defaultMessage;
                const field = erro.field;
                console.error(`Erro no campo ${field}: ${mensagem}`);
            }

        } else if (httpResp.ok && (httpResp.status === 200 || httpResp.status === 201)) {
            alert('Sucesso ao salvar produto');
            document.getElementById('addItemEstoqueLojaForm').reset();
        } else {
            alert('Erro no envio dos dados - ' + httpResp.status);
        }

    } catch (error) {
        console.error('Erro na requisição:', error);
        alert('Erro inesperado ao enviar os dados');
    }
}

// EDITAR produto -
async function editarDadosProduto() {
    console.log("Editar Produto" + idProduto)
    const form = document.getElementById('addItemEstoqueLojaForm');

    const dadosProduto = {
        codProduto: form.txtCodItemLoja.value,
        nome: form.txtNomeLoja.value,
        marca: form.txtMarcaLoja.value,
        descricao: form.txtDescricaoLoja.value,
        quantidade: form.txtQtdeLoja.value,
        preco: form.txtPrecoLoja.value
    };
    console.log(dadosProduto)

    const httpResp = await fetch(`/api/motoparts/produto/${idProduto}`, {
        method: 'put',
        headers: {
            'content-type': 'application/json'
        },
        body: JSON.stringify(dadosProduto)
    });
    if (!httpResp.ok) {
        if (httpResp.status !== 400) {
            alert('Erro no envio dos dados - ' + httpResp.status);
            return;
        }
        const erros = await httpResp.json();
        for (const erro of erros.errors) {
            const mensagem = erro.defaultMessage;
            const field = erro.field;
            console.log(mensagem)
        }
    }
    alert('Sucesso ao editar o produto');
}

// EXCLUIR produto - OK
async function excluirItemProduto(id) {
    const httpResp = await fetch(`/api/motoparts/produto/${id}`, {
        method: 'delete',
        headers: {
            'content-type': 'application/json'
        },
    });

    if (httpResp.ok) {
        alert("Produto excluída")
        window.location.reload();
        return
    }
}

// CARREGAR produto - OK
async function carregarEstoque() {
    const dadosLocalStorage = JSON.parse(localStorage.getItem("dados"));

    const idLocalStorage = dadosLocalStorage.id;
    console.log("IDL" + idLocalStorage);
    const permissaoLocalStorage = dadosLocalStorage.permissao;
    let url = permissaoLocalStorage !== "ADMIN"
        ? `/api/motoparts/produto/fornecedor/${idLocalStorage}`
        : `/api/motoparts/produto`;

    const resposta = await fetch(url);
    if (!resposta.ok) {
        throw new Error('Erro ao carregar os dados da API.');
        return;
    }

    const dados = await resposta.json();
    const tabelaCorpo = document.getElementById('estoqueLoja');
    tabelaCorpo.innerHTML = '';

    if (dados && dados.length > 0) {
        
        dados.forEach(item => {

            const linha = document.createElement('tr');

            const preco = `R$ ${parseFloat(item.preco).toFixed(2)}`;

            const colunas = [
                item.id,
                item.codProduto,
                item.nome,
                item.descricao,
                item.marca,
                item.quantidade,
                preco,
            ];

            // Para cada coluna, criar uma célula e adicionar à linha
            colunas.forEach(dado => {
                const celula = document.createElement('td');
                celula.textContent = dado;
                linha.appendChild(celula);
            });

            // Célula para o ícone de editar (ex: lápis)
            const editarCelula = document.createElement('td');
            editarCelula.innerHTML = '<a href="#" style="color: #343a40" "><i class="fas fa-pencil-alt"></i></a>';
            editarCelula.addEventListener('click', () => editarItemProduto(item.id));
            linha.appendChild(editarCelula);

            const visualizarCelula = document.createElement('td');
            visualizarCelula.innerHTML = '<i class="fas fa-id-card"></i>';
            visualizarCelula.addEventListener('click', () => visualizarItem(item.id));
            linha.appendChild(visualizarCelula);

            const excluirCelula = document.createElement('td');
            excluirCelula.innerHTML = '<a href="#" style="color: #343a40" "><i class="fas fa-trash-alt"></i></a>';
            excluirCelula.addEventListener('click', () => excluirItemProduto(item.id));
            linha.appendChild(excluirCelula);

            // Adicionar a linha à tabela
            tabelaCorpo.appendChild(linha);
        });
    } else {
        // Se não houver dados,
        tabelaCorpo.innerHTML = '<tr><td colspan="10">Nenhum item encontrado.</td></tr>';
    }
}

async function editarItemProduto(id) {
    //Pegar informações do produto
    const resposta = await fetch(`/api/motoparts/produto/${id}`);
    const dadosProduto = await resposta.json();

    // Define o id do produto para variável global
    idProduto = id;
    preencherModalComDadosProduto(dadosProduto);

    // Abre o modal
    var modal = new bootstrap.Modal(document.getElementById('addItemEstoqueLoja'));
    modal.show();
}

// Funções Auxiliares
function preencherModalComDadosProduto(dados) {

    // Campos bloqueados para edição
    document.getElementById('txtNomeLoja').value = dados.nome;
    document.getElementById('txtNomeLoja').readOnly = true;
    document.getElementById('txtCodItemLoja').value = dados.codProduto;
    document.getElementById('txtCodItemLoja').readOnly = true;
    document.getElementById('txtMarcaLoja').value = dados.marca;
    document.getElementById('txtMarcaLoja').readOnly = true;

    document.getElementById('txtDescricaoLoja').value = dados.descricao || '';
    document.getElementById('txtQtdeLoja').value = dados.quantidade || '';
    document.getElementById('txtPrecoLoja').value = dados.preco || '';

}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('collapsed');
}

function toggleSubMenu(subMenuId) {
    const allSubMenus = document.querySelectorAll('.sub-menu');
    allSubMenus.forEach(subMenu => {
        subMenu.classList.remove('active');
    });
    const currentSubMenu = document.getElementById(subMenuId);
    currentSubMenu.classList.toggle('active');
}

$('#addItemEstoqueLoja').on('hidden.bs.modal', function () {
    $('.resettable').val('');
    $('.error-message').hide();
});

function blockLetters(input) {
    input.value = input.value.replace(/[^0-9,]/g, '');
}

window.onload = function () {
    carregarEstoque();
    document.getElementById('addItemEstoqueLojaForm').reset();
};

